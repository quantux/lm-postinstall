##### Credits

 * The creators of El General (now known as Antu), off which
   La Capitaine is based: https://github.com/fabianalexisinostroza/Antu
 * The creators of Numix icon set, the base of El General:
   https://github.com/numixproject/numix-icon-theme-circle
 * The creators of Emoji One, the emoji which I used in /emotes:
   http://emojione.com
 * The creators of the Material Design Icons project for some symbolic
   icons and emblems: https://materialdesignicons.com
 * The creators of Super Flat Remix, off which the trash icons are
   based: https://github.com/daniruiz/Super-Flat-Remix

##### Notes
La Capitaine was forked from El General Gnome in the Autumn of 2015;
this project diverged from that base before Antu existed, and these two
distinct icon themes share the same base.
