### Thanks!
Thank you so much to the generous people who are helping to support this
project. You guys inspire me to be my very best, and keep my development
on going. Cheers all!

#### Significant contibutors
This is a list of people who have supported me with significant _code_
contributions. Cheers to them! :computer:

 * Andreas K. ([@DarkknightAK](https://github.com/darkknightak))
    - added proper support for the KDE Plasma desktop environment
 * [@RaitaroH](https://github.com/RaitaroH)
    - recoloured many many icons to make the dark variant of
      La Capitaine possible
 * [@demoy](https://github.com/demoy)
   - Helped hunt down and destroy problems with some action icons that
     weren't being detected by my SVG renderer
 * Sergey Artemov ([@firefoxic](https://github.com/firefoxic))
   - Assisted with reducing overall size of project
 * [@now-im](https://github.com/now-im)
   - Added KDE style attributes to monochrome icons, such that the theme
     respects the desktop colourscheme
   - Contributes new icons regularly!
 * [@Riotism](https://github.com/Riotism)
   - Contributes new icons, and audits design!
   - Has been a huge help finding compatibility issues

#### Significant donors
This is a list of people who have supported me with significant
donations through [Paypal](https://paypal.me/keeferrourke) or
[Patreon](https://www.patreon.com/krourke). Cheers to them! :grin:

 * Anonymous donations from Pling GmbH

